
#include "fsm.h"

Fsm & Fsm::begin() {

    const static state_t state_table[] PROGMEM = {
    /*                    ON_ENTER      ON_LOOP      ON_EXIT   CMD_STOP   CMD_PARAM    CMD_REF  CMD_MATCH   EVT_MD   ELSE */
    /* IDLE      */       ENT_IDLE,          -1,          -1,      IDLE,      PARAM, REFERENCE,     MATCH,      -1,    -1,
    /* PARAM     */      ENT_PARAM,  LOOP_PARAM,  EXIT_PARAM,      IDLE,         -1,        -1,        -1,      -1,    -1,
    /* REFERENCE */       ENT_REF,     LOOP_REF,    EXIT_REF,      IDLE,         -1,        -1,        -1,      -1,    -1,
    /* MATCH     */     ENT_MATCH,   LOOP_MATCH,  EXIT_MATCH,      IDLE,         -1,        -1,        -1,  MATCH2,    -1,
    /* MATCH2    */    ENT_MATCH2,   LOOP_MATCH, EXIT_MATCH2,      IDLE,         -1,        -1,        -1,      -1,    -1,
    };

    Machine::begin( state_table, ELSE );
    timer.set(5000);
    return *this;
}

int Fsm::event( int id ) {
  // switch (id)
  // {
  //   case CMD_STOP:
  //     Serial.println("CMD_STOP");
  //     return 1;
  //   case CMD_PARAM:
  //     Serial.println("CMD_PARAM");
  //     return 1;
  // }
  return 0;
}

void Fsm::action( int id ) {
  if(id!=ENT_IDLE){
    digitalWrite( LED_BUILTIN, HIGH );
  }
  switch ( id ) {
    case ENT_IDLE:
  	  digitalWrite( LED_BUILTIN, LOW );
  	  return;
    case ENT_PARAM:
      param_enter();
      return;  // wait for serial and start command containing number of channels
    case LOOP_PARAM:
      if(param_loop()){
        Fsm::trigger(Fsm::CMD_STOP);
      }
  	  return;
    case EXIT_PARAM:
      param_exit();
  	  return;
    case ENT_REF:
      reference_enter();
      return;
    case LOOP_REF:
      if(reference_loop()){
        Fsm::trigger(Fsm::CMD_STOP);
      }
      return;
    case EXIT_REF:
      reference_exit();
      return;
    case ENT_MATCH:
      match_enter();
      return;
    case LOOP_MATCH:
      if(!match_loop()){
        Fsm::trigger(Fsm::CMD_STOP);
      }
      return;
    case EXIT_MATCH:
      match_exit();
      Fsm::trigger(Fsm::EVT_MD);
      return;
    case ENT_MATCH2:
      match2_enter();
      return;
    case EXIT_MATCH2:
      match2_exit();
      return;
  }
}

Fsm & Fsm::trace( Stream & stream ) {
  Machine::setTrace( &stream, atm_serial_debug::trace,
    "FSM\0CMD_STOP\0CMD_PARAM\0CMD_REF\0CMD_MATCH\0EVT_MD\0ELSE\0IDLE\0PARAM\0REFERENCE\0MATCH\0MATCH2");
  return *this;
}

#define DMX_HOLD_COUNT 0

uint8_t param_chnanels = 4;
uint8_t param_dmx_step = 10;
uint8_t param_hold_count = 0;

extern TCS34725 tcs;

// reference/match
int ref_address = 0;
int ref_count = 0;

// param
uint8_t dmx_cur[10] = { };  // init all to zero
uint8_t dmx_old[10] = { };  // init all to zero
uint8_t dmx_start_address = 1;
uint16_t r, g, b, c = 0;
uint16_t *rgbc[] = {&r, &g, &b, &c};
uint32_t rgbc32[4] = { };
uint16_t rgbc_reference[4] = { };
uint8_t hold_counter = 0;
bool wait_for_start = true;
uint32_t loop_count = 0;
bool finished = false;

float rgb_rel_cur[3] = { };
float rgb_rel_target[3] = { };
uint8_t match_index_abs = 0;

// match2

void match2_enter(){
  Serial.println("MATCH2_ENTER");
  uint8_t i_max = get_max_index(dmx_cur);
  dmx_cur[i_max] = 255;
  match_index_abs = i_max;
}

void match2_exit(){
  Serial.println("MATCH2_EXIT");
}

// match
void match_enter(){
  Serial.println("MATCH_ENTER");
  read_reference(ref_address);
  make_relative(rgb_rel_target, rgbc_reference);
  memset(dmx_old, 0, sizeof(dmx_old));
  memset(dmx_cur, 128, sizeof(dmx_old));
}

bool match_loop(){   // iterate loop
  uint16_t m = iterate();
  Serial.print("m: ");
  Serial.println(m);
  if (compareArray(dmx_cur, dmx_old)){
    return true;
  }
  dmx_cur[0] = dmx_old[0];
  dmx_cur[1] = dmx_old[1];
  dmx_cur[2] = dmx_old[2];
}

//function to compare array elements
bool compareArray(uint8_t a[],uint8_t b[])	{
	for(int i=0;i<3;i++){
		if(a[i]!=b[i])
			return false;
	}
	return true;
}

void match_exit(){
  Serial.println("MATCH_EXIT");
}

uint8_t iterate(){
  dmx_cur[match_index_abs] = 128;
  uint8_t index = match_index_abs + 1;
  uint16_t itersum = 0;
  uint8_t m = 0;
  while(m<21){
    uint8_t index_shifted = (index - 1) % param_chnanels;
    tcs.startIntegration();
    while(!tcs.is_integrated());
    tcs.read_data_rgbc(&r, &g, &b, &c);
    make_relative(rgb_rel_cur, *rgbc);
    float rel_diff = rgb_rel_target[index_shifted] - rgb_rel_cur[index_shifted];

    if (abs(rel_diff) < 0.005 || (m>0 && m%20==0)){
      itersum += m;
      index++;
      m=0;
    }

    if(index>=param_chnanels){
      index = 0;
    }

    if (index == match_index_abs){
      return itersum;
    }

    if(rel_diff>0){
      if (rel_diff < .1f){
        dmx_cur[index] -= 1;
      }else{
        dmx_cur[index] -= 5;
      }
    } else if(rel_diff<0){
      if (rel_diff > -.1f){
        dmx_cur[index] += 1;
      }else{
        dmx_cur[index] += 5;
      }
    }

    write_dmx(dmx_cur);

    Serial.print(m);
    Serial.print(": ");
    Serial.print(dmx_cur[0]);
    Serial.print(", ");
    Serial.print(dmx_cur[1]);
    Serial.print(", ");
    Serial.println(dmx_cur[2]);

    m++;

  }

  return -42;
}

uint8_t get_max_index(uint8_t dmx[]){
  uint8_t max_index = 0;
  for (uint8_t i=0; i<(uint8_t)sizeof(&dmx); i++){
    if (dmx[i] > dmx[max_index]){
      max_index = i;
    }
  }
  return max_index;
}

void make_relative(float target[3], uint16_t source[4]){
  target[0] = source[0]/source[1];
  target[1] = source[1]/source[2];
  target[2] = source[2]/source[0];
}


void reference_enter(){
  Serial.println("REFERENCE_ENTER");
  rgbc32[4] = { };
}

// reference
bool reference_loop(){
  Serial.println("REFERENCE_LOOP");
  //tcs.integrate_2_min_norm(1024, &r, &g, &b, &c);
  tcs.startIntegration();
  while (!tcs.is_integrated());
  tcs.read_data_rgbc(&r, &g, &b, &c);
  for(uint8_t a=0; a<(uint8_t)sizeof(&rgbc); a++){
    rgbc32[a] = rgbc32[a] + (uint32_t) &rgbc[a];
  }
  Serial.print(ref_count);
  Serial.print(": ");
  Serial.print(r);
  Serial.print(", ");
  Serial.print(g);
  Serial.print(", ");
  Serial.print(b);
  Serial.print(", ");
  Serial.println(c);
  ref_count++;
  if(ref_count>=9){
    return true;
  }
  return false;
}

void reference_exit(){
  Serial.println("REFERENCE_EXIT");
  for (uint8_t a=0; a<(uint8_t)sizeof(&rgbc); a++){
    rgbc_reference[a] = (uint16_t) &rgbc[a]/10;
  }
  save_reference(ref_address);
}

void save_reference(uint16_t address){
  for(uint8_t a=0; a< (uint8_t)sizeof(rgbc); a++){
    EEPROM.put(address+a*2, rgbc_reference[a]);
  }
}

void read_reference(uint16_t address){
  for(uint8_t a=0; a< (uint8_t)sizeof(rgbc); a++){
    rgbc_reference[a] = EEPROM.get(address+a*2, rgbc_reference[a]);
  }
}

// param
void param_enter(){
    Serial.println("PARAM_ENTER");
    write_dmx_on();
    return;
}

bool param_loop(){

  if (wait_for_start){
    return true;
  }

  loop_count++;

  if (loop_count == 1){
    write_dmx_off();
    delay(10);
  }

  tcs.startIntegration();
  //do computing send old values from previous loop

  if(loop_count > 1){
    print_values();
  }
  
  for(int i = 0; i<param_chnanels; i++){
    dmx_old[i] = dmx_cur[i];
  }

  //increase_dmx_value(3, DMX_STEPS);
  increase_dmx_values(param_dmx_step);
  //wait until integration is finished
  while (!tcs.is_integrated());
  //write dmx new (use the time of serial out)
  write_dmx(dmx_cur);
  tcs.read_data_rgbc(&r, &g, &b, &c);
  delay(20);

  if(finished){
    print_values();
    return false;
  }

  return true;

}

void param_exit(){
    Serial.println("PARAM_EXIT");
    wait_for_start = true;
    write_dmx_off();
    return;
}

bool param_read_serial(String str){
    if(str.startsWith("start")){
        wait_for_start = false;
        return true;
    } else if (str.startsWith("param_chnanels")){
        write_dmx_off();
        param_chnanels = extract_int(str, param_chnanels);
        write_dmx_on();
    } else if ( str.startsWith("param_dmx_step")){
        param_dmx_step = extract_int(str, param_dmx_step);
    } else if ( str.startsWith("param_hold_count")){
        param_hold_count = extract_int(str, param_hold_count);
    } else if ( str.startsWith("dmx_start_address")){
        dmx_start_address = extract_int(str, dmx_start_address);
    } else if ( str.startsWith("reset")) {
        // do nothing, reset will be called below. 
    } else {
      return false;
    }
    param_reset();
    return true;
}

void param_reset(){
  for (uint8_t i = 0; i < sizeof(dmx_cur); i++){
    dmx_cur[i] = 0;
    dmx_old[i] = 0;
  }  
  hold_counter = 0;
  wait_for_start = true;
  loop_count = 0;
  finished = false;
}

uint8_t extract_int(String str, uint8_t defaultInt){
  String numString;
  bool inStartsWith = true;
  for (uint8_t i = 0; i < str.length(); i++){
    char numChar = str.charAt(i);
    if(inStartsWith){
      if(isDigit(numChar)){
        inStartsWith = false;
      } else {
        continue;
      }
    }
    if (isDigit(numChar)){
      numString += numChar;
      continue;
    }
    break;
  }
  return numString.toInt();
}

void increase_dmx_values(uint8_t inc_step) {
  if (hold_counter == 0) {
    for(int i = param_chnanels; i >= 0; i--){
      if (dmx_cur[i] == 0){
        if(i>0){
          increase_dmx_value(i-1, inc_step);
        } else {
          finished = true;
        }
        continue;
      }
      break;
    }
  } else {
    hold_counter--;
  }
}

void increase_dmx_value(uint8_t index, uint8_t inc_step) {
  uint16_t val = dmx_cur[index];
  val = val + inc_step;
  if (val > (uint16_t)255 && val < (uint16_t)(255 + inc_step)) {
    val = 255;
  }
  if (val == (uint16_t)(255 + inc_step)) {
    val = 0;
  }
  if (val > (uint16_t)255) {
    val = 0;
  }
  hold_counter = param_hold_count;
  dmx_cur[index] = val;
}

void write_dmx(uint8_t values[]) {
  for(int i = 0; i < param_chnanels; i++){
    DMXSerial.write(i+dmx_start_address, values[i]);
  }
}

void write_dmx_all(uint8_t val) {
  for(int i = 0; i < param_chnanels; i++){
    DMXSerial.write(i+dmx_start_address, val);
  }
}

void write_dmx_on() {
  write_dmx_all(255);
}

void write_dmx_off() {
  //write_dmx_all(0);
  for(int i = 1; i <= 255; i++){
    DMXSerial.write(i, 0);
  }
}

void print_values() {
  char buff[32];
  sprintf(buff, "%05d, %05d, %05d, %05d", r, g, b, c);
  String str_print = buff;
  for(int i = 0; i < param_chnanels; i++){
    sprintf(buff, ", %03d", dmx_old[i]);
    str_print += buff;
  }
  Serial.println(str_print);
}
